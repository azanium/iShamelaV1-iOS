﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace iShamela
{
    public class CatTable
    {
        public CatTable()
        {
            Id = 0;
            Name = "";
            CatOrd = 0;
            Lvl = 0;
        }

        public static Dictionary<long, CatTable> GenerateIdMap(List<CatTable> tables)
        {
            Dictionary<long, CatTable> map = new Dictionary<long, CatTable>();
            foreach (CatTable cat in tables)
            {
                map.Add(cat.Id, cat);
            }
            return map;
        }

        public static List<CatTable> Fill(DbJet db)
        {
            OleDbDataReader reader = db.Read("select * from 0cat");

            List<CatTable> tables = new List<CatTable>();
            Dictionary<string, object> fields = new Dictionary<string, object>();

            while (reader.Read())
            {
                // Fields will help us to overcome non seq order
                fields.Clear();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    fields.Add(reader.GetName(i).ToLower(), reader.GetValue(i));
                }

                CatTable table = new CatTable();
                table.Id = long.Parse(fields["id"].ToString());
                table.Name = fields["name"].ToString();
                table.CatOrd = long.Parse(fields["catord"].ToString());
                table.Lvl = long.Parse(fields["lvl"].ToString());

                tables.Add(table);
            }

            return tables;
        }

        public long Id { get; set; }
        public string Name { get; set; }
        public long CatOrd { get; set; }
        public long Lvl { get; set; }
    }
}
